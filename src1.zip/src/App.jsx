import { BrowserRouter, Routes, Route } from "react-router-dom";

// Pages
import Welcome from "./pages/Welcome";
import Login from "./pages/Login";

// Other Pages (Uncomment when you create them)
// import Register from "./pages/Register";
// import AdminDashboard from "./pages/AdminDashboard";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Landing Page */}
        <Route path="/" element={<Welcome />} />

        {/* Login */}
        <Route path="/login" element={<Login />} />

        {/* Future Routes */}

        {/*
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<AdminDashboard />} />
        */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;