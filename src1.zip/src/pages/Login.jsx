import { useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Checkbox,
  Chip,
  CssBaseline,
  Divider,
  FormControlLabel,
  Grid,
  IconButton,
  InputAdornment,
  Link,
  Stack,
  TextField,
  Typography,
} from "@mui/material";

import {
  AnalyticsRounded,
  ArrowForwardRounded,
  Email,
  Lock,
  PlayArrowRounded,
  SecurityRounded,
  Visibility,
  VisibilityOff,
  WaterDrop,
  WaterDropRounded,
} from "@mui/icons-material";

import { GoogleLogin } from "@react-oauth/google";

import axios from "axios";

import api from "../services/api";

import background from "../images/welcome-bg.jpg";
import logo from "../images/logo.png";

import "../styles/login.css";

function Login() {

  const navigate = useNavigate();

  const [showPassword, setShowPassword] = useState(false);

  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");

  // ===============================
  // LOGIN
  // ===============================

  const handleLogin = async (e) => {

    e.preventDefault();

    try {

      const response = await api.post("/auth/login", {
        email,
        password,
      });

      localStorage.setItem("token", response.data.token);
      localStorage.setItem("role", response.data.role);
      localStorage.setItem("username", response.data.username);
      localStorage.setItem("email", response.data.email);

      alert("Login Successful!");

      if (response.data.role === "ADMIN") {
        navigate("/admin-dashboard");
      } else {
        navigate("/resident-dashboard");
      }

    } catch (error) {

      console.log(error);

      alert("Invalid Email or Password");

    }

  };

  // ===============================
  // GOOGLE LOGIN
  // ===============================

  const handleGoogleLogin = async (credentialResponse) => {

    try {

      const response = await axios.post(
        "http://localhost:8082/auth/google",
        {
          token: credentialResponse.credential,
        }
      );

      localStorage.setItem("token", response.data.token);
      localStorage.setItem("role", response.data.role);
      localStorage.setItem("username", response.data.username);
      localStorage.setItem("email", response.data.email);

      alert("Google Login Successful!");

      if (response.data.role === "ADMIN") {
        navigate("/admin-dashboard");
      } else {
        navigate("/resident-dashboard");
      }

    } catch (error) {

      console.log(error);

      alert("Google Login Failed");

    }

  };

  return (

    <>

      <CssBaseline />

      <Box
        sx={{
          minHeight: "100vh",
          position: "relative",
          overflow: "hidden",

          backgroundImage: `linear-gradient(rgba(4,18,40,.92),rgba(5,30,60,.92)), url(${background})`,

          backgroundSize: "cover",

          backgroundPosition: "center",

          display: "flex",

          justifyContent: "center",

          alignItems: "center",

          px: {
            xs: 2,
            md: 6,
          },

          py: 5,
        }}
      >

        {/* Background Decoration */}

        <Box
          sx={{
            position: "absolute",
            width: 300,
            height: 300,
            borderRadius: "50%",
            bgcolor: "rgba(33,150,243,.12)",
            filter: "blur(50px)",
            top: -100,
            left: -100,
          }}
        />

        <Box
          sx={{
            position: "absolute",
            width: 250,
            height: 250,
            borderRadius: "50%",
            bgcolor: "rgba(0,188,212,.12)",
            filter: "blur(40px)",
            bottom: 50,
            right: 60,
          }}
        />

        <Grid
          container
          sx={{
            maxWidth: 1450,

            borderRadius: 6,

            overflow: "hidden",

            backdropFilter: "blur(20px)",

            background: "rgba(255,255,255,.05)",

            border: "1px solid rgba(255,255,255,.08)",

            boxShadow: "0 25px 60px rgba(0,0,0,.35)",
          }}
        >
                    {/* ========================= */}
          {/* LEFT SIDE */}
          {/* ========================= */}

          <Grid
            item
            xs={12}
            md={6}
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              p: {
                xs: 4,
                md: 8,
              },
            }}
          >
            <Stack spacing={5}>

              {/* Logo */}

              <Box
                display="flex"
                alignItems="center"
                gap={2.5}
              >
                <Avatar
                  src={logo}
                  sx={{
                    width: 70,
                    height: 70,
                    bgcolor: "#fff",
                    transition: ".35s",

                    "&:hover": {
                      transform: "rotate(-8deg) scale(1.08)",
                    },
                  }}
                />

                <Box>
                  <Typography
                    sx={{
                      color: "#fff",
                      fontWeight: 800,
                      fontSize: 34,
                    }}
                  >
                    AquaTrack
                  </Typography>

                  <Typography
                    sx={{
                      color: "#90CAF9",
                      fontSize: 17,
                    }}
                  >
                    Smart Water Management Platform
                  </Typography>
                </Box>
              </Box>

              {/* Badge */}

              <Chip
                label="ENTERPRISE WATER MANAGEMENT"
                sx={{
                  width: "fit-content",
                  bgcolor: "rgba(33,150,243,.15)",
                  color: "#64B5F6",
                  fontWeight: 700,
                  letterSpacing: 1,
                  borderRadius: 6,
                }}
              />

              {/* Heading */}

              <Typography
                sx={{
                  color: "#fff",
                  fontWeight: 800,
                  lineHeight: 1.15,
                  fontSize: {
                    xs: 38,
                    md: 56,
                  },
                }}
              >
                Manage Water
                <br />
                Smarter,
                <br />
                Every Day.
              </Typography>

              {/* Description */}

              <Typography
                sx={{
                  color: "#CFD8DC",
                  fontSize: 18,
                  lineHeight: 1.9,
                  maxWidth: 620,
                }}
              >
                AquaTrack enables apartment communities to
                monitor water usage, automate billing,
                detect leakages, manage residents and
                generate insightful analytics through one
                secure cloud platform.
              </Typography>

              {/* Features */}

              <Stack spacing={3}>

                {[
                  {
                    icon: <WaterDropRounded />,
                    title: "Real-Time Water Monitoring",
                    desc: "Track water usage instantly across every household.",
                    color: "#29B6F6",
                  },
                  {
                    icon: <AnalyticsRounded />,
                    title: "Advanced Analytics",
                    desc: "Interactive reports and monthly consumption trends.",
                    color: "#42A5F5",
                  },
                  {
                    icon: <SecurityRounded />,
                    title: "Secure Platform",
                    desc: "Role-based authentication with JWT security.",
                    color: "#66BB6A",
                  },
                  {
                    icon: <WaterDrop />,
                    title: "Leak Detection",
                    desc: "Receive alerts whenever abnormal usage is detected.",
                    color: "#26C6DA",
                  },
                ].map((item) => (

                  <Stack
                    key={item.title}
                    direction="row"
                    spacing={3}
                    alignItems="flex-start"
                    sx={{
                      transition: ".35s",

                      "&:hover": {
                        transform: "translateX(8px)",
                      },
                    }}
                  >

                    <Avatar
                      sx={{
                        width: 56,
                        height: 56,
                        bgcolor: `${item.color}22`,
                        color: item.color,
                        transition: ".35s",
                      }}
                    >
                      {item.icon}
                    </Avatar>

                    <Box>

                      <Typography
                        sx={{
                          color: "#fff",
                          fontWeight: 700,
                          fontSize: 21,
                          mb: .5,
                        }}
                      >
                        {item.title}
                      </Typography>

                      <Typography
                        sx={{
                          color: "#B0BEC5",
                          lineHeight: 1.8,
                          fontSize: 15,
                        }}
                      >
                        {item.desc}
                      </Typography>

                    </Box>

                  </Stack>

                ))}

              </Stack>

              {/* Statistics */}

              <Stack
                direction="row"
                spacing={6}
                sx={{
                  mt: 3,
                  flexWrap: "wrap",
                }}
              >

                <Box>

                  <Typography
                    sx={{
                      color: "#42A5F5",
                      fontSize: 34,
                      fontWeight: 800,
                    }}
                  >
                    24/7
                  </Typography>

                  <Typography
                    sx={{
                      color: "#CFD8DC",
                    }}
                  >
                    Monitoring
                  </Typography>

                </Box>

                <Box>

                  <Typography
                    sx={{
                      color: "#42A5F5",
                      fontSize: 34,
                      fontWeight: 800,
                    }}
                  >
                    100%
                  </Typography>

                  <Typography
                    sx={{
                      color: "#CFD8DC",
                    }}
                  >
                    Secure Access
                  </Typography>

                </Box>

                <Box>

                  <Typography
                    sx={{
                      color: "#42A5F5",
                      fontSize: 34,
                      fontWeight: 800,
                    }}
                  >
                    AI
                  </Typography>

                  <Typography
                    sx={{
                      color: "#CFD8DC",
                    }}
                  >
                    Leak Alerts
                  </Typography>

                </Box>

              </Stack>

            </Stack>
          </Grid>
                    {/* ========================= */}
          {/* RIGHT SIDE */}
          {/* ========================= */}

          <Grid
            item
            xs={12}
            md={6}
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              p: {
                xs: 3,
                md: 6,
              },
            }}
          >
            <Card
              elevation={0}
              sx={{
                width: "100%",
                maxWidth: 500,
                borderRadius: 5,
                backdropFilter: "blur(20px)",
                background: "rgba(10,25,45,.88)",
                border: "1px solid rgba(255,255,255,.08)",
                color: "#fff",
                transition: ".35s",

                "&:hover": {
                  transform: "translateY(-8px)",
                  boxShadow: "0 30px 70px rgba(0,0,0,.35)",
                },
              }}
            >
              <CardContent sx={{ p: 5 }}>

                <Chip
                  label="WELCOME BACK"
                  sx={{
                    mb: 3,
                    bgcolor: "rgba(33,150,243,.15)",
                    color: "#64B5F6",
                    fontWeight: 700,
                    letterSpacing: 1,
                    borderRadius: 5,
                  }}
                />

                <Typography
                  sx={{
                    fontWeight: 800,
                    fontSize: {
                      xs: 36,
                      md: 46,
                    },
                    mb: 1,
                  }}
                >
                  Sign In
                </Typography>

                <Typography
                  sx={{
                    color: "#B0BEC5",
                    fontSize: 16,
                    mb: 4,
                    lineHeight: 1.7,
                  }}
                >
                  Welcome back! Sign in to continue managing
                  your apartment's water management system.
                </Typography>

                <form onSubmit={handleLogin}>

                  {/* Email */}

                  <TextField
                    fullWidth
                    required
                    type="email"
                    label="Email Address"
                    placeholder="Enter your email"
                    margin="normal"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Email sx={{ color: "#42A5F5" }} />
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      mb: 2,

                      "& .MuiOutlinedInput-root": {
                        borderRadius: "14px",
                        background: "rgba(255,255,255,.06)",
                        color: "#fff",

                        "& fieldset": {
                          borderColor: "rgba(255,255,255,.12)",
                        },

                        "&:hover fieldset": {
                          borderColor: "#42A5F5",
                        },

                        "&.Mui-focused fieldset": {
                          borderColor: "#42A5F5",
                        },
                      },

                      "& .MuiInputLabel-root": {
                        color: "#B0BEC5",
                      },

                      "& input::placeholder": {
                        color: "#90A4AE",
                        opacity: 1,
                      },
                    }}
                  />

                  {/* Password */}

                  <TextField
                    fullWidth
                    required
                    margin="normal"
                    label="Password"
                    placeholder="Enter your password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Lock sx={{ color: "#42A5F5" }} />
                        </InputAdornment>
                      ),

                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton
                            onClick={() =>
                              setShowPassword(!showPassword)
                            }
                            edge="end"
                            sx={{
                              color: "#B0BEC5",
                            }}
                          >
                            {showPassword ? (
                              <VisibilityOff />
                            ) : (
                              <Visibility />
                            )}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: "14px",
                        background: "rgba(255,255,255,.06)",
                        color: "#fff",

                        "& fieldset": {
                          borderColor: "rgba(255,255,255,.12)",
                        },

                        "&:hover fieldset": {
                          borderColor: "#42A5F5",
                        },

                        "&.Mui-focused fieldset": {
                          borderColor: "#42A5F5",
                        },
                      },

                      "& .MuiInputLabel-root": {
                        color: "#B0BEC5",
                      },
                    }}
                  />

                  <Box
                    sx={{
                      mt: 2,
                      mb: 3,
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <FormControlLabel
                      control={
                        <Checkbox
                          sx={{
                            color: "#90A4AE",

                            "&.Mui-checked": {
                              color: "#42A5F5",
                            },
                          }}
                        />
                      }
                      label={
                        <Typography
                          sx={{
                            color: "#CFD8DC",
                            fontSize: 14,
                          }}
                        >
                          Remember Me
                        </Typography>
                      }
                    />

                    <Link
                      component="button"
                      underline="hover"
                      onClick={() =>
                        navigate("/forgot-password")
                      }
                      sx={{
                        color: "#64B5F6",
                        fontWeight: 600,
                        fontSize: 14,
                      }}
                    >
                      Forgot Password?
                    </Link>
                  </Box>

                  <Button
                    fullWidth
                    type="submit"
                    variant="contained"
                    endIcon={<ArrowForwardRounded />}
                    sx={{
                      py: 1.8,
                      borderRadius: "14px",
                      textTransform: "none",
                      fontSize: 17,
                      fontWeight: 700,

                      background:
                        "linear-gradient(90deg,#1976D2,#42A5F5)",

                      boxShadow:
                        "0 15px 35px rgba(33,150,243,.35)",

                      transition: ".35s",

                      "&:hover": {
                        transform: "translateY(-3px)",

                        boxShadow:
                          "0 20px 45px rgba(33,150,243,.45)",

                        background:
                          "linear-gradient(90deg,#1565C0,#2196F3)",
                      },
                    }}
                  >
                    Sign In
                  </Button>
                                    <Divider
                    sx={{
                      my: 4,
                      color: "#90A4AE",

                      "&::before,&::after": {
                        borderColor: "rgba(255,255,255,.12)",
                      },
                    }}
                  >
                    OR
                  </Divider>

                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                      mb: 4,
                    }}
                  >
                    <GoogleLogin
                      onSuccess={handleGoogleLogin}
                      onError={() => {
                        alert("Google Login Failed");
                      }}
                    />
                  </Box>

                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<PlayArrowRounded />}
                    onClick={() => navigate("/")}
                    sx={{
                      py: 1.5,
                      mb: 4,
                      borderRadius: "14px",
                      textTransform: "none",
                      fontWeight: 700,
                      fontSize: 16,

                      color: "#E3F2FD",

                      borderColor: "rgba(255,255,255,.20)",

                      "&:hover": {
                        borderColor: "#42A5F5",
                        background: "rgba(66,165,245,.08)",
                      },
                    }}
                  >
                    Back to Home
                  </Button>

                  <Typography
                    align="center"
                    sx={{
                      color: "#90A4AE",
                      fontSize: 15,
                    }}
                  >
                    Need access? Contact your apartment administrator.
                  </Typography>

                </form>

                <Divider
                  sx={{
                    my: 4,

                    "&::before,&::after": {
                      borderColor: "rgba(255,255,255,.08)",
                    },
                  }}
                />

                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                >
                  <Box
                    display="flex"
                    alignItems="center"
                    gap={1}
                  >
                    <WaterDropRounded
                      sx={{
                        color: "#42A5F5",
                      }}
                    />

                    <Typography
                      sx={{
                        color: "#CFD8DC",
                        fontWeight: 700,
                      }}
                    >
                      AquaTrack
                    </Typography>
                  </Box>

                  <Typography
                    sx={{
                      color: "#78909C",
                      fontSize: 13,
                    }}
                  >
                    Version 1.0
                  </Typography>

                </Box>

              </CardContent>

            </Card>

          </Grid>

        </Grid>

      </Box>

    </>

  );

}

export default Login;