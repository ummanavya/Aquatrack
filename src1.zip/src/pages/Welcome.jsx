import React from "react";
import HeroSection from "../components/HeroSection";

function Welcome() {
  return (
    <>
      <HeroSection />
    </>
  );
}

export default Welcome;