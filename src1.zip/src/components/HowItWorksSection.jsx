import React from "react";
import { motion } from "framer-motion";

import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
  Avatar,
} from "@mui/material";

import ApartmentRoundedIcon from "@mui/icons-material/ApartmentRounded";
import WaterDropRoundedIcon from "@mui/icons-material/WaterDropRounded";
import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";
import AnalyticsRoundedIcon from "@mui/icons-material/AnalyticsRounded";

const steps = [
  {
    number: "01",
    icon: <ApartmentRoundedIcon />,
    title: "Register Apartment",
    description:
      "Create apartments, add households and configure water meters for every resident.",
  },
  {
    number: "02",
    icon: <WaterDropRoundedIcon />,
    title: "Track Water Usage",
    description:
      "Record daily water meter readings and monitor consumption in real time.",
  },
  {
    number: "03",
    icon: <ReceiptLongRoundedIcon />,
    title: "Generate Bills",
    description:
      "Automatically calculate monthly bills using configurable tariff plans.",
  },
  {
    number: "04",
    icon: <AnalyticsRoundedIcon />,
    title: "Monitor Analytics",
    description:
      "View dashboards, identify abnormal usage and receive instant leak alerts.",
  },
];

const fadeUp = {
  hidden: {
    opacity: 0,
    y: 40,
  },

  show: (delay = 0) => ({
    opacity: 1,
    y: 0,

    transition: {
      duration: 0.8,
      delay,
    },
  }),
};

export default function HowItWorksSection() {
  return (
    <Box
      sx={{
        py: {
          xs: 10,
          md: 14,
        },
        bgcolor: "#FFFFFF",
      }}
    >
      <Container maxWidth="xl">

        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >
          <Typography
            align="center"
            sx={{
              color: "#1976D2",
              fontWeight: 700,
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            Workflow
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              fontWeight: 800,
              color: "#0F172A",
              fontSize: {
                xs: "2rem",
                md: "3rem",
              },
            }}
          >
            How AquaTrack Works
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              maxWidth: 760,
              mx: "auto",
              color: "#64748B",
              lineHeight: 1.8,
            }}
          >
            AquaTrack simplifies apartment water management through an
            intelligent workflow that automates monitoring, billing and
            analytics from start to finish.
          </Typography>
        </motion.div>

        {/* Continue in Part 5B */}
                <Grid
          container
          spacing={4}
          sx={{
            mt: 6,
          }}
        >
          {steps.map((step, index) => (
            <Grid
              item
              xs={12}
              sm={6}
              lg={3}
              key={step.number}
            >
              <motion.div
                variants={fadeUp}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true }}
                custom={index * 0.15}
              >
                <Paper
                  elevation={0}
                  sx={{
                    height: "100%",
                    p: 4,
                    borderRadius: "24px",
                    border: "1px solid #E2E8F0",
                    background: "#FFFFFF",
                    position: "relative",
                    transition: "all .35s ease",

                    "&:hover": {
                      transform: "translateY(-10px)",
                      borderColor: "#42A5F5",
                      boxShadow:
                        "0 20px 50px rgba(25,118,210,.15)",
                    },
                  }}
                >
                  <Typography
                    sx={{
                      position: "absolute",
                      top: 20,
                      right: 24,
                      fontSize: "2.5rem",
                      fontWeight: 800,
                      color: "#E3F2FD",
                    }}
                  >
                    {step.number}
                  </Typography>

                  <Avatar
                    sx={{
                      width: 72,
                      height: 72,
                      bgcolor: "#1976D2",
                      mb: 3,
                    }}
                  >
                    {step.icon}
                  </Avatar>

                  <Typography
                    sx={{
                      fontWeight: 700,
                      fontSize: "1.35rem",
                      color: "#0F172A",
                      mb: 2,
                    }}
                  >
                    {step.title}
                  </Typography>

                  <Typography
                    sx={{
                      color: "#64748B",
                      lineHeight: 1.8,
                    }}
                  >
                    {step.description}
                  </Typography>
                </Paper>
              </motion.div>
            </Grid>
          ))}
        </Grid>

        {/* Continue in Part 5C */}
                <Box
          sx={{
            mt: 10,
            p: {
              xs: 4,
              md: 6,
            },
            borderRadius: "30px",
            background:
              "linear-gradient(135deg,#1976D2,#42A5F5)",
            color: "#FFFFFF",
          }}
        >
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            custom={0.3}
          >
            <Typography
              align="center"
              sx={{
                fontWeight: 800,
                fontSize: {
                  xs: "2rem",
                  md: "3rem",
                },
              }}
            >
              From Water Reading to Smart Billing
            </Typography>

            <Typography
              align="center"
              sx={{
                mt: 3,
                maxWidth: 850,
                mx: "auto",
                color: "rgba(255,255,255,.9)",
                lineHeight: 1.9,
                fontSize: 18,
              }}
            >
              AquaTrack automates every stage of apartment water
              management—from recording meter readings to generating
              accurate bills, detecting leaks, and delivering
              meaningful analytics through one centralized platform.
            </Typography>

            <Grid
              container
              spacing={4}
              sx={{
                mt: 5,
              }}
            >
              {[
                {
                  value: "24×7",
                  label: "Real-Time Monitoring",
                },
                {
                  value: "100%",
                  label: "Automated Billing",
                },
                {
                  value: "AI",
                  label: "Leak Detection",
                },
                {
                  value: "Cloud",
                  label: "Secure Data Access",
                },
              ].map((item) => (
                <Grid
                  item
                  xs={6}
                  md={3}
                  key={item.label}
                >
                  <Box
                    sx={{
                      textAlign: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        fontWeight: 800,
                        fontSize: {
                          xs: "2rem",
                          md: "2.7rem",
                        },
                        color: "#FFFFFF",
                      }}
                    >
                      {item.value}
                    </Typography>

                    <Typography
                      sx={{
                        mt: 1,
                        color: "rgba(255,255,255,.85)",
                      }}
                    >
                      {item.label}
                    </Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </motion.div>
        </Box>

      </Container>
    </Box>
  );
}