import React from "react";
import { motion } from "framer-motion";

import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Container,
  Typography,
} from "@mui/material";

import ExpandMoreRoundedIcon from "@mui/icons-material/ExpandMoreRounded";

const faqs = [
  {
    question: "How does AquaTrack monitor water usage?",
    answer:
      "AquaTrack records smart meter readings and provides real-time monitoring, enabling apartment administrators and residents to track daily, weekly, and monthly water consumption.",
  },
  {
    question: "Can AquaTrack automatically generate water bills?",
    answer:
      "Yes. AquaTrack automatically calculates water bills using configurable tariff plans, ensuring transparent and accurate billing for every household.",
  },
  {
    question: "Does AquaTrack detect water leaks?",
    answer:
      "Yes. Intelligent analytics continuously monitor abnormal consumption patterns and notify administrators whenever a possible leak is detected.",
  },
  {
    question: "Can residents view their own water usage?",
    answer:
      "Absolutely. Residents can securely access their dashboard to monitor consumption, bills, payment history, and notifications.",
  },
  {
    question: "Is AquaTrack secure?",
    answer:
      "Yes. AquaTrack uses secure authentication, role-based access control, encrypted communication, and protected APIs to keep data safe.",
  },
];

const fadeUp = {
  hidden: {
    opacity: 0,
    y: 30,
  },

  show: (delay = 0) => ({
    opacity: 1,
    y: 0,

    transition: {
      duration: .7,
      delay,
    },
  }),
};

export default function FAQSection() {

  return (

    <Box
      sx={{
        py: {
          xs: 8,
          md: 10,
        },
        bgcolor: "#F8FAFC",
      }}
    >

      <Container maxWidth="lg">

        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >

          <Typography
            align="center"
            sx={{
              color: "#1976D2",
              fontWeight: 700,
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            Frequently Asked Questions
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              fontWeight: 800,
              color: "#0F172A",
              fontSize: {
                xs: "2.2rem",
                md: "3rem",
              },
            }}
          >
            Everything You Need To Know
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              mb: 5,
              maxWidth: 720,
              mx: "auto",
              color: "#64748B",
              lineHeight: 1.9,
            }}
          >
            Find answers to the most common questions about AquaTrack,
            including monitoring, billing, security, alerts and
            apartment management.
          </Typography>

        </motion.div>

        {/* Continue in Part 4B */}
                {faqs.map((faq, index) => (
          <motion.div
            key={faq.question}
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            custom={index * 0.1}
          >
            <Accordion
              disableGutters
              elevation={0}
              sx={{
                mb: 2,
                borderRadius: "20px !important",
                overflow: "hidden",
                border: "1px solid #E2E8F0",
                background: "#FFFFFF",
                transition: ".35s",

                "&::before": {
                  display: "none",
                },

                "&:hover": {
                  borderColor: "#42A5F5",
                  boxShadow: "0 15px 35px rgba(25,118,210,.12)",
                },

                "&.Mui-expanded": {
                  borderColor: "#1976D2",
                  boxShadow: "0 20px 40px rgba(25,118,210,.18)",
                },
              }}
            >
              <AccordionSummary
                expandIcon={
                  <ExpandMoreRoundedIcon
                    sx={{
                      color: "#1976D2",
                      transition: ".3s",
                    }}
                  />
                }
                sx={{
                  px: 3,
                  py: 1,

                  "& .MuiAccordionSummary-content": {
                    my: 1,
                  },

                  "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded":
                    {
                      transform: "rotate(180deg)",
                    },
                }}
              >
                <Typography
                  sx={{
                    fontWeight: 700,
                    color: "#0F172A",
                    fontSize: {
                      xs: "1rem",
                      md: "1.08rem",
                    },
                  }}
                >
                  {faq.question}
                </Typography>
              </AccordionSummary>

              <AccordionDetails
                sx={{
                  px: 3,
                  py: 3,
                  background:
                    "linear-gradient(135deg,#1976D2,#42A5F5)",
                  color: "#FFFFFF",
                  borderTop: "1px solid rgba(255,255,255,.15)",
                }}
              >
                <Typography
                  sx={{
                    lineHeight: 1.9,
                    color: "#FFFFFF",
                    fontSize: ".98rem",
                  }}
                >
                  {faq.answer}
                </Typography>
              </AccordionDetails>
            </Accordion>
          </motion.div>
        ))}

        {/* Continue in Part 4C */}
                {/* ================= SUPPORT BANNER ================= */}

        <Box
          sx={{
            mt: 5,
            p: {
              xs: 3,
              md: 4,
            },
            borderRadius: "24px",
            background:
              "linear-gradient(135deg,#1565C0,#42A5F5)",
            color: "#FFFFFF",
          }}
        >
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
          >
            <Typography
              align="center"
              sx={{
                fontWeight: 800,
                fontSize: {
                  xs: "1.8rem",
                  md: "2.4rem",
                },
              }}
            >
              Still Have Questions?
            </Typography>

            <Typography
              align="center"
              sx={{
                mt: 1.5,
                color: "rgba(255,255,255,.92)",
                maxWidth: 720,
                mx: "auto",
                lineHeight: 1.8,
              }}
            >
              Our support team is always ready to help you with setup,
              billing, water monitoring and apartment management.
            </Typography>

            <Grid
              container
              spacing={3}
              justifyContent="center"
              sx={{
                mt: 4,
              }}
            >
              {[
                {
                  value: "24×7",
                  label: "Support",
                },
                {
                  value: "99.9%",
                  label: "Availability",
                },
                {
                  value: "256-bit",
                  label: "Encryption",
                },
                {
                  value: "<1 hr",
                  label: "Response Time",
                },
              ].map((item) => (
                <Grid
                  item
                  xs={6}
                  md={3}
                  key={item.label}
                >
                  <Paper
                    elevation={0}
                    sx={{
                      py: 2,
                      borderRadius: 3,
                      textAlign: "center",
                      background: "rgba(255,255,255,.14)",
                      backdropFilter: "blur(12px)",
                      border: "1px solid rgba(255,255,255,.18)",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#FFFFFF",
                        fontWeight: 800,
                        fontSize: "1.8rem",
                      }}
                    >
                      {item.value}
                    </Typography>

                    <Typography
                      sx={{
                        mt: 0.5,
                        color: "rgba(255,255,255,.9)",
                        fontSize: ".9rem",
                      }}
                    >
                      {item.label}
                    </Typography>
                  </Paper>
                </Grid>
              ))}
            </Grid>
          </motion.div>
        </Box>

      </Container>
    </Box>
  );
}