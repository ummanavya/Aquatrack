import {
  Box,
  Container,
  Divider,
  Grid,
  IconButton,
  Link,
  Stack,
  Typography,
} from "@mui/material";

import WaterDropRoundedIcon from "@mui/icons-material/WaterDropRounded";
import FacebookRoundedIcon from "@mui/icons-material/FacebookRounded";
import LinkedInRoundedIcon from "@mui/icons-material/LinkedInRounded";
import GitHubIcon from "@mui/icons-material/GitHub";
import XIcon from "@mui/icons-material/X";

export default function Footer() {
  const quickLinks = [
    "Home",
    "Features",
    "Dashboard",
    "Analytics",
    "Contact",
  ];

  const products = [
    "Water Monitoring",
    "Billing Engine",
    "Leak Detection",
    "Reports",
    "Resident Portal",
  ];

  return (
    <Box
      sx={{
        bgcolor: "#0F172A",
        color: "#fff",
        pt: 10,
        pb: 4,
      }}
    >
      <Container maxWidth="xl">

        <Grid container spacing={6}>

          {/* Logo */}

          <Grid item xs={12} md={4}>

            <Stack
              direction="row"
              spacing={2}
              alignItems="center"
              mb={3}
            >
              <Box
                sx={{
                  width: 56,
                  height: 56,
                  borderRadius: "18px",
                  background:
                    "linear-gradient(135deg,#1976D2,#42A5F5)",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <WaterDropRoundedIcon sx={{ color: "#fff" }} />
              </Box>

              <Typography
                variant="h5"
                fontWeight={800}
              >
                AquaTrack
              </Typography>

            </Stack>

            <Typography
              sx={{
                color: "#CBD5E1",
                lineHeight: 1.9,
                mb: 4,
              }}
            >
              AquaTrack is an intelligent apartment water
              management platform that combines real-time
              monitoring, automated billing, analytics and
              leak detection into one secure dashboard.
            </Typography>

            <Stack direction="row" spacing={1}>

              {[FacebookRoundedIcon,
                LinkedInRoundedIcon,
                GitHubIcon,
                XIcon].map((Icon, index) => (

                <IconButton
                  key={index}
                  sx={{
                    bgcolor: "rgba(255,255,255,.08)",
                    color: "#fff",

                    "&:hover": {
                      bgcolor: "#1976D2",
                    },
                  }}
                >
                  <Icon />
                </IconButton>

              ))}

            </Stack>

          </Grid>

          {/* Quick Links */}

          <Grid item xs={6} md={2}>

            <Typography
              fontWeight={700}
              mb={3}
            >
              Quick Links
            </Typography>

            <Stack spacing={2}>

              {quickLinks.map((item) => (

                <Link
                  key={item}
                  href="#"
                  underline="none"
                  color="#CBD5E1"
                >
                  {item}
                </Link>

              ))}

            </Stack>

          </Grid>

          {/* Products */}

          <Grid item xs={6} md={3}>

            <Typography
              fontWeight={700}
              mb={3}
            >
              Products
            </Typography>

            <Stack spacing={2}>

              {products.map((item) => (

                <Link
                  key={item}
                  href="#"
                  underline="none"
                  color="#CBD5E1"
                >
                  {item}
                </Link>

              ))}

            </Stack>

          </Grid>

          {/* Contact */}

          <Grid item xs={12} md={3}>

            <Typography
              fontWeight={700}
              mb={3}
            >
              Contact
            </Typography>

            <Stack spacing={2}>

              <Typography color="#CBD5E1">
                📍 Vijayawada, Andhra Pradesh
              </Typography>

              <Typography color="#CBD5E1">
                📧 info@aquatrack.com
              </Typography>

              <Typography color="#CBD5E1">
                📞 +91 98765 43210
              </Typography>

            </Stack>

          </Grid>

        </Grid>

        <Divider
          sx={{
            borderColor: "rgba(255,255,255,.10)",
            my: 6,
          }}
        />

        <Stack
          direction={{
            xs: "column",
            md: "row",
          }}
          justifyContent="space-between"
          alignItems="center"
          spacing={2}
        >

          <Typography color="#94A3B8">
            © 2026 AquaTrack. All Rights Reserved.
          </Typography>

          <Typography color="#94A3B8">
            Built with React • Material UI • Spring Boot
          </Typography>

        </Stack>

      </Container>
    </Box>
  );
}