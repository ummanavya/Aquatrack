import React from "react";
import { motion } from "framer-motion";

import {
  Avatar,
  Box,
  Container,
  Grid,
  Paper,
  Rating,
  Typography,
  Stack,
} from "@mui/material";

const testimonials = [
  {
    name: "Ramesh Kumar",
    role: "Apartment Administrator",
    rating: 5,
    review:
      "AquaTrack completely automated our billing process. Water tracking is now effortless and residents love the transparency.",
  },
  {
    name: "Priya Sharma",
    role: "Resident",
    rating: 5,
    review:
      "The dashboard is simple, clean and helps me monitor my family's daily water consumption in real time.",
  },
  {
    name: "Arjun Reddy",
    role: "Maintenance Manager",
    rating: 5,
    review:
      "Leak alerts helped us identify abnormal usage early, preventing significant water loss and reducing monthly costs.",
  },
];

const fadeUp = {
  hidden: {
    opacity: 0,
    y: 35,
  },

  show: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.7,
      delay,
    },
  }),
};

export default function TestimonialsSection() {
  return (
    <Box
      sx={{
        py: {
          xs: 8,
          md: 10,
        },
        bgcolor: "#FFFFFF",
      }}
    >
      <Container maxWidth="xl">

        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >
          <Typography
            align="center"
            sx={{
              color: "#1976D2",
              fontWeight: 700,
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            Testimonials
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              fontWeight: 800,
              color: "#0F172A",
              fontSize: {
                xs: "2.2rem",
                md: "3rem",
              },
            }}
          >
            Loved by Apartment Communities
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              mb: 5,
              maxWidth: 720,
              mx: "auto",
              color: "#64748B",
              lineHeight: 1.8,
            }}
          >
            Discover how AquaTrack helps apartment administrators,
            maintenance teams and residents manage water efficiently.
          </Typography>

        </motion.div>

        {/* Continue in Part 3B */}
                <Grid
          container
          spacing={3}
          justifyContent="center"
          alignItems="stretch"
        >
          {testimonials.map((item, index) => (
            <Grid
              item
              xs={12}
              md={4}
              key={item.name}
            >
              <motion.div
                variants={fadeUp}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true }}
                custom={index * 0.15}
                style={{ height: "100%" }}
              >
                <Paper
                  elevation={0}
                  sx={{
                    p: 4,
                    height: "100%",
                    borderRadius: "24px",
                    border: "1px solid #E2E8F0",
                    background:
                      "linear-gradient(180deg,#FFFFFF,#F8FBFF)",
                    transition: ".35s",

                    "&:hover": {
                      transform: "translateY(-10px)",
                      boxShadow:
                        "0 20px 45px rgba(25,118,210,.12)",
                      borderColor: "#64B5F6",
                    },
                  }}
                >
                  <Stack
                    direction="row"
                    spacing={2}
                    alignItems="center"
                    mb={3}
                  >
                    <Avatar
                      sx={{
                        width: 64,
                        height: 64,
                        bgcolor: "#1976D2",
                        fontWeight: 700,
                        fontSize: "1.2rem",
                      }}
                    >
                      {item.name.charAt(0)}
                    </Avatar>

                    <Box>
                      <Typography
                        sx={{
                          fontWeight: 700,
                          color: "#0F172A",
                        }}
                      >
                        {item.name}
                      </Typography>

                      <Typography
                        sx={{
                          color: "#64748B",
                          fontSize: ".9rem",
                        }}
                      >
                        {item.role}
                      </Typography>
                    </Box>
                  </Stack>

                  <Rating
                    value={item.rating}
                    readOnly
                    sx={{
                      mb: 2,
                    }}
                  />

                  <Typography
                    sx={{
                      color: "#475569",
                      lineHeight: 1.9,
                      minHeight: 130,
                    }}
                  >
                    "{item.review}"
                  </Typography>
                </Paper>
              </motion.div>
            </Grid>
          ))}
        </Grid>

        {/* Continue in Part 3C */}
                {/* ================= TRUST BANNER ================= */}

        <Paper
          elevation={0}
          sx={{
            mt: 5,
            p: {
              xs: 3,
              md: 4,
            },
            borderRadius: "28px",
            background:
              "linear-gradient(135deg,#1565C0,#42A5F5)",
            overflow: "hidden",
            position: "relative",
          }}
        >
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
          >
            <Typography
              align="center"
              sx={{
                color: "#FFFFFF",
                fontWeight: 800,
                fontSize: {
                  xs: "1.8rem",
                  md: "2.5rem",
                },
              }}
            >
              Trusted by Modern Apartment Communities
            </Typography>

            <Typography
              align="center"
              sx={{
                mt: 1.5,
                color: "rgba(255,255,255,.9)",
                maxWidth: 760,
                mx: "auto",
                lineHeight: 1.8,
              }}
            >
              Helping apartments simplify water monitoring, billing,
              analytics and leak detection with one intelligent platform.
            </Typography>

            <Grid
              container
              spacing={3}
              justifyContent="center"
              sx={{
                mt: 4,
              }}
            >
              {[
                {
                  value: "120+",
                  label: "Communities",
                },
                {
                  value: "18K+",
                  label: "Bills Generated",
                },
                {
                  value: "99.9%",
                  label: "Accuracy",
                },
                {
                  value: "4.9★",
                  label: "User Rating",
                },
              ].map((item) => (
                <Grid
                  item
                  xs={6}
                  md={3}
                  key={item.label}
                >
                  <Paper
                    elevation={0}
                    sx={{
                      py: 2.5,
                      borderRadius: 4,
                      textAlign: "center",
                      background: "rgba(255,255,255,.12)",
                      backdropFilter: "blur(12px)",
                      border: "1px solid rgba(255,255,255,.15)",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#FFFFFF",
                        fontWeight: 800,
                        fontSize: "2rem",
                      }}
                    >
                      {item.value}
                    </Typography>

                    <Typography
                      sx={{
                        mt: .5,
                        color: "rgba(255,255,255,.85)",
                        fontSize: ".95rem",
                      }}
                    >
                      {item.label}
                    </Typography>
                  </Paper>
                </Grid>
              ))}
            </Grid>
          </motion.div>
        </Paper>

      </Container>
    </Box>
  );
}