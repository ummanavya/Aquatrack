import React from "react";
import { motion } from "framer-motion";

import {
  Box,
  Button,
  Container,
  Stack,
  Typography,
} from "@mui/material";

import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import EmailRoundedIcon from "@mui/icons-material/EmailRounded";

const fadeUp = {
  hidden: {
    opacity: 0,
    y: 40,
  },

  show: (delay = 0) => ({
    opacity: 1,
    y: 0,

    transition: {
      duration: 0.8,
      delay,
    },
  }),
};

export default function CTASection() {
  return (
    <Box
      sx={{
        py: {
          xs: 10,
          md: 14,
        },
        bgcolor: "#FFFFFF",
      }}
    >
      <Container maxWidth="lg">

        <Box
          sx={{
            position: "relative",
            overflow: "hidden",
            borderRadius: "36px",
            background:
              "linear-gradient(135deg,#0F172A 0%,#1976D2 50%,#42A5F5 100%)",
            p: {
              xs: 5,
              md: 8,
            },
          }}
        >
          {/* Decorative Circles */}

          <Box
            sx={{
              position: "absolute",
              width: 320,
              height: 320,
              borderRadius: "50%",
              background: "rgba(255,255,255,.08)",
              top: -120,
              left: -120,
            }}
          />

          <Box
            sx={{
              position: "absolute",
              width: 240,
              height: 240,
              borderRadius: "50%",
              background: "rgba(255,255,255,.06)",
              bottom: -80,
              right: -80,
            }}
          />

          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
          >

            {/* Continue in Part 8B */}
                        <Typography
              sx={{
                color: "#90CAF9",
                textTransform: "uppercase",
                letterSpacing: 2,
                fontWeight: 700,
                textAlign: "center",
              }}
            >
              Ready to Get Started?
            </Typography>

            <Typography
              sx={{
                mt: 2,
                textAlign: "center",
                color: "#FFFFFF",
                fontWeight: 800,
                lineHeight: 1.2,
                fontSize: {
                  xs: "2.2rem",
                  sm: "2.8rem",
                  md: "3.5rem",
                },
              }}
            >
              Start Managing Water
              <br />
              Smarter with AquaTrack
            </Typography>

            <Typography
              sx={{
                mt: 3,
                textAlign: "center",
                color: "rgba(255,255,255,.85)",
                maxWidth: 760,
                mx: "auto",
                lineHeight: 1.9,
                fontSize: {
                  xs: "1rem",
                  md: "1.1rem",
                },
              }}
            >
              Simplify water monitoring, automate billing, detect leaks,
              and gain valuable insights into consumption with one
              intelligent platform designed for modern apartment
              communities.
            </Typography>

            <Stack
              direction={{
                xs: "column",
                sm: "row",
              }}
              spacing={3}
              justifyContent="center"
              alignItems="center"
              sx={{
                mt: 6,
              }}
            >
              <Button
                variant="contained"
                size="large"
                endIcon={<ArrowForwardRoundedIcon />}
                sx={{
                  px: 5,
                  py: 1.8,
                  borderRadius: "50px",
                  fontWeight: 700,
                  textTransform: "none",
                  fontSize: "1rem",
                  bgcolor: "#FFFFFF",
                  color: "#1976D2",

                  "&:hover": {
                    bgcolor: "#F5F5F5",
                    transform: "translateY(-3px)",
                  },
                }}
              >
                Get Started
              </Button>

              <Button
                variant="outlined"
                size="large"
                startIcon={<EmailRoundedIcon />}
                sx={{
                  px: 5,
                  py: 1.8,
                  borderRadius: "50px",
                  fontWeight: 700,
                  textTransform: "none",
                  fontSize: "1rem",
                  borderColor: "rgba(255,255,255,.5)",
                  color: "#FFFFFF",

                  "&:hover": {
                    borderColor: "#FFFFFF",
                    bgcolor: "rgba(255,255,255,.08)",
                    transform: "translateY(-3px)",
                  },
                }}
              >
                Contact Us
              </Button>
            </Stack>

            {/* Continue in Part 8C */}
                        <Stack
              direction={{
                xs: "column",
                sm: "row",
              }}
              spacing={{
                xs: 3,
                md: 6,
              }}
              justifyContent="center"
              alignItems="center"
              sx={{
                mt: 7,
                pt: 5,
                borderTop: "1px solid rgba(255,255,255,.15)",
              }}
            >
              {[
                "✓ Secure Authentication",
                "✓ Real-Time Monitoring",
                "✓ Automated Billing",
                "✓ Smart Leak Detection",
              ].map((item) => (
                <Typography
                  key={item}
                  sx={{
                    color: "rgba(255,255,255,.9)",
                    fontWeight: 600,
                    textAlign: "center",
                  }}
                >
                  {item}
                </Typography>
              ))}
            </Stack>

          </motion.div>
        </Box>

      </Container>
    </Box>
  );
}