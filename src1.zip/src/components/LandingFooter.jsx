import React from "react";
import { motion } from "framer-motion";

import {
  Box,
  Container,
  Grid,
  IconButton,
  Link,
  Stack,
  Typography,
} from "@mui/material";

import EmailRoundedIcon from "@mui/icons-material/EmailRounded";
import PhoneRoundedIcon from "@mui/icons-material/PhoneRounded";
import LocationOnRoundedIcon from "@mui/icons-material/LocationOnRounded";

import FacebookRoundedIcon from "@mui/icons-material/FacebookRounded";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import InstagramIcon from "@mui/icons-material/Instagram";
import XIcon from "@mui/icons-material/X";

const fadeUp = {
  hidden: {
    opacity: 0,
    y: 30,
  },

  show: (delay = 0) => ({
    opacity: 1,
    y: 0,

    transition: {
      duration: 0.7,
      delay,
    },
  }),
};

export default function LandingFooter() {
  return (
    <Box
      sx={{
        bgcolor: "#08111F",
        color: "#FFFFFF",
        pt: 6,
        pb: 2,
      }}
    >
      <Container maxWidth="xl">

        <Grid
          container
          spacing={4}
        >

          {/* Continue in Part 5B */}
                    {/* ================= BRAND ================= */}

          <Grid item xs={12} md={4}>
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
            >
              <Typography
                sx={{
                  fontWeight: 800,
                  fontSize: "2rem",
                  color: "#42A5F5",
                }}
              >
                AquaTrack
              </Typography>

              <Typography
                sx={{
                  mt: 2,
                  color: "rgba(255,255,255,.75)",
                  lineHeight: 1.8,
                  maxWidth: 340,
                }}
              >
                AquaTrack is an intelligent water usage and billing
                management platform that enables apartment communities to
                monitor consumption, generate bills automatically, detect
                leaks, and gain valuable insights through analytics.
              </Typography>

              <Stack
                direction="row"
                spacing={1.5}
                sx={{ mt: 3 }}
              >
                {[
                  <FacebookRoundedIcon />,
                  <InstagramIcon />,
                  <LinkedInIcon />,
                  <XIcon />,
                ].map((icon, index) => (
                  <IconButton
                    key={index}
                    sx={{
                      bgcolor: "rgba(255,255,255,.08)",
                      color: "#FFFFFF",
                      width: 42,
                      height: 42,
                      transition: ".3s",

                      "&:hover": {
                        bgcolor: "#1976D2",
                        transform: "translateY(-4px)",
                      },
                    }}
                  >
                    {icon}
                  </IconButton>
                ))}
              </Stack>
            </motion.div>
          </Grid>

          {/* ================= QUICK LINKS ================= */}

          <Grid item xs={6} md={2}>
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              custom={0.1}
            >
              <Typography
                sx={{
                  fontWeight: 700,
                  mb: 2,
                  color: "#FFFFFF",
                }}
              >
                Quick Links
              </Typography>

              <Stack spacing={1.2}>
                {[
                  "Home",
                  "Features",
                  "Dashboard",
                  "Testimonials",
                  "FAQ",
                ].map((item) => (
                  <Link
                    key={item}
                    underline="none"
                    href={`#${item.toLowerCase()}`}
                    sx={{
                      color: "rgba(255,255,255,.7)",
                      transition: ".3s",

                      "&:hover": {
                        color: "#42A5F5",
                        pl: 1,
                      },
                    }}
                  >
                    {item}
                  </Link>
                ))}
              </Stack>
            </motion.div>
          </Grid>

          {/* ================= SERVICES ================= */}

          <Grid item xs={6} md={2}>
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              custom={0.2}
            >
              <Typography
                sx={{
                  fontWeight: 700,
                  mb: 2,
                }}
              >
                Services
              </Typography>

              <Stack spacing={1.2}>
                {[
                  "Water Monitoring",
                  "Billing",
                  "Leak Detection",
                  "Analytics",
                  "Reports",
                ].map((item) => (
                  <Typography
                    key={item}
                    sx={{
                      color: "rgba(255,255,255,.7)",
                    }}
                  >
                    {item}
                  </Typography>
                ))}
              </Stack>
            </motion.div>
          </Grid>

          {/* Continue in Part 5C */}
                    {/* ================= CONTACT ================= */}

          <Grid item xs={12} md={4}>
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              custom={0.3}
            >
              <Typography
                sx={{
                  fontWeight: 700,
                  mb: 2,
                }}
              >
                Contact Us
              </Typography>

              <Stack spacing={2}>

                <Stack direction="row" spacing={2} alignItems="center">
                  <EmailRoundedIcon sx={{ color: "#42A5F5" }} />
                  <Typography sx={{ color: "rgba(255,255,255,.75)" }}>
                    support@aquatrack.com
                  </Typography>
                </Stack>

                <Stack direction="row" spacing={2} alignItems="center">
                  <PhoneRoundedIcon sx={{ color: "#42A5F5" }} />
                  <Typography sx={{ color: "rgba(255,255,255,.75)" }}>
                    +91 98765 43210
                  </Typography>
                </Stack>

                <Stack direction="row" spacing={2} alignItems="flex-start">
                  <LocationOnRoundedIcon
                    sx={{
                      color: "#42A5F5",
                      mt: 0.3,
                    }}
                  />
                  <Typography
                    sx={{
                      color: "rgba(255,255,255,.75)",
                      lineHeight: 1.7,
                    }}
                  >
                    Vijayawada, Andhra Pradesh,
                    <br />
                    India
                  </Typography>
                </Stack>

              </Stack>
            </motion.div>
          </Grid>

        </Grid>

        {/* ================= COPYRIGHT ================= */}

        <Box
          sx={{
            mt: 5,
            pt: 2.5,
            borderTop: "1px solid rgba(255,255,255,.10)",
            display: "flex",
            flexDirection: {
              xs: "column",
              md: "row",
            },
            justifyContent: "space-between",
            alignItems: "center",
            gap: 1.5,
          }}
        >
          <Typography
            sx={{
              color: "rgba(255,255,255,.6)",
              fontSize: ".9rem",
            }}
          >
            © {new Date().getFullYear()} AquaTrack. All Rights Reserved.
          </Typography>

          <Typography
            sx={{
              color: "rgba(255,255,255,.6)",
              fontSize: ".9rem",
            }}
          >
            Designed & Developed with ❤️ using React & Material UI
          </Typography>
        </Box>

      </Container>
    </Box>
  );
}