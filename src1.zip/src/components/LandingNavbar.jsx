import { useEffect, useState } from "react";
import {
  AppBar,
  Toolbar,
  Container,
  Typography,
  Button,
  Stack,
  Box,
} from "@mui/material";
import WaterDropRoundedIcon from "@mui/icons-material/WaterDropRounded";
import { useNavigate } from "react-router-dom";

function LandingNavbar() {
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll();

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const menu = [
    { name: "Home", id: "#home" },
    { name: "Features", id: "#features" },
    { name: "How It Works", id: "#how" },
    { name: "Testimonials", id: "#testimonials" },
    { name: "FAQ", id: "#faq" },
    { name: "Contact", id: "#contact" },
  ];

  return (
    <AppBar
      position="fixed"
      elevation={0}
      sx={{
        background: scrolled
          ? "rgba(255,255,255,0.88)"
          : "rgba(255,255,255,0.65)",
        backdropFilter: "blur(18px)",
        WebkitBackdropFilter: "blur(18px)",
        borderBottom: "1px solid rgba(226,232,240,.8)",
        transition: "all .4s ease",
      }}
    >
      <Container maxWidth="xl">
        <Toolbar
          disableGutters
          sx={{
            height: scrolled ? 72 : 88,
            transition: ".4s",
            justifyContent: "space-between",
          }}
        >
          {/* Logo */}
          <Stack
            direction="row"
            spacing={2}
            alignItems="center"
            sx={{
              cursor: "pointer",
              transition: ".3s",
              "&:hover .logoBox": {
                transform: "rotate(12deg) scale(1.08)",
              },
            }}
          >
            <Box
              className="logoBox"
              sx={{
                width: scrolled ? 50 : 56,
                height: scrolled ? 50 : 56,
                borderRadius: "18px",
                background:
                  "linear-gradient(135deg,#1976D2,#42A5F5)",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                color: "#fff",
                transition: ".4s",
                boxShadow:
                  "0 14px 30px rgba(25,118,210,.35)",
              }}
            >
              <WaterDropRoundedIcon sx={{ fontSize: 28 }} />
            </Box>

            <Box>
              <Typography
                sx={{
                  fontSize: scrolled ? 28 : 30,
                  fontWeight: 800,
                  color: "#0F172A",
                  lineHeight: 1,
                  transition: ".3s",
                }}
              >
                AquaTrack
              </Typography>

              <Typography
                sx={{
                  color: "#64748B",
                  fontSize: 13,
                  mt: 0.4,
                }}
              >
                Smart Water Management
              </Typography>
            </Box>
          </Stack>

          {/* Menu */}
          <Stack
            direction="row"
            spacing={5}
            sx={{
              display: {
                xs: "none",
                md: "flex",
              },
            }}
          >
            {menu.map((item) => (
              <Button
                key={item.name}
                href={item.id}
                disableRipple
                sx={{
                  color: "#334155",
                  fontWeight: 600,
                  fontSize: 15,
                  textTransform: "none",
                  position: "relative",

                  "&::after": {
                    content: '""',
                    position: "absolute",
                    bottom: 6,
                    left: "50%",
                    transform: "translateX(-50%)",
                    width: 0,
                    height: 3,
                    borderRadius: 10,
                    bgcolor: "#1976D2",
                    transition: ".35s",
                  },

                  "&:hover": {
                    bgcolor: "transparent",
                    color: "#1976D2",
                  },

                  "&:hover::after": {
                    width: "75%",
                  },
                }}
              >
                {item.name}
              </Button>
            ))}
          </Stack>

          {/* Login Button */}
          <Button
            variant="contained"
            onClick={() => navigate("/login")}
            sx={{
              px: 4.5,
              py: 1.4,
              borderRadius: "40px",
              textTransform: "none",
              fontWeight: 700,
              background:
                "linear-gradient(135deg,#1976D2,#42A5F5)",
              boxShadow:
                "0 12px 30px rgba(25,118,210,.35)",
              transition: ".35s",

              "&:hover": {
                background:
                  "linear-gradient(135deg,#1565C0,#2196F3)",
                transform: "translateY(-3px)",
                boxShadow:
                  "0 18px 40px rgba(25,118,210,.45)",
              },
            }}
          >
            Login
          </Button>
        </Toolbar>
      </Container>
    </AppBar>
  );
}

export default LandingNavbar;