import React from "react";
import { motion } from "framer-motion";

import {
  Avatar,
  Box,
  Chip,
  Container,
  Grid,
  LinearProgress,
  Paper,
  Stack,
  Typography,
} from "@mui/material";

import WaterDropRoundedIcon from "@mui/icons-material/WaterDropRounded";
import CurrencyRupeeRoundedIcon from "@mui/icons-material/CurrencyRupeeRounded";
import WarningAmberRoundedIcon from "@mui/icons-material/WarningAmberRounded";
import PieChartRoundedIcon from "@mui/icons-material/PieChartRounded";
import AnalyticsRoundedIcon from "@mui/icons-material/AnalyticsRounded";
import TrendingUpRoundedIcon from "@mui/icons-material/TrendingUpRounded";

const fadeUp = {
  hidden: {
    opacity: 0,
    y: 40,
  },

  show: (delay = 0) => ({
    opacity: 1,
    y: 0,

    transition: {
      duration: .7,
      delay,
    },
  }),
};

const summaryCards = [
  {
    title: "Water Usage",
    value: "18,420 L",
    color: "#1976D2",
    icon: <WaterDropRoundedIcon />,
  },
  {
    title: "Revenue",
    value: "₹1.82L",
    color: "#2E7D32",
    icon: <CurrencyRupeeRoundedIcon />,
  },
  {
    title: "Alerts",
    value: "02",
    color: "#ED6C02",
    icon: <WarningAmberRoundedIcon />,
  },
  {
    title: "Efficiency",
    value: "94%",
    color: "#7B1FA2",
    icon: <TrendingUpRoundedIcon />,
  },
];

export default function DashboardShowcase() {

  return (

    <Box
      sx={{
        py: {
          xs: 8,
          md: 10,
        },
        bgcolor: "#F8FAFC",
      }}
    >

      <Container maxWidth="xl">

        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >

          <Typography
            align="center"
            sx={{
              color: "#1976D2",
              fontWeight: 700,
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            Dashboard Preview
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              fontWeight: 800,
              color: "#0F172A",
              fontSize: {
                xs: "2.2rem",
                md: "3.2rem",
              },
            }}
          >
            Powerful Analytics At A Glance
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              maxWidth: 760,
              mx: "auto",
              color: "#64748B",
              lineHeight: 1.9,
              mb: 6,
            }}
          >
            Everything you need to monitor apartment water
            usage, billing, leak alerts and analytics in
            one beautiful dashboard.
          </Typography>

        </motion.div>

        {/* Continue in Part 2B */}
                {/* ================= SUMMARY CARDS ================= */}

        <Grid
          container
          spacing={3}
          sx={{
            mb: 4,
          }}
        >
          {summaryCards.map((card, index) => (
            <Grid
              item
              xs={12}
              sm={6}
              md={3}
              key={card.title}
            >
              <motion.div
                variants={fadeUp}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true }}
                custom={index * 0.1}
              >
                <Paper
                  elevation={0}
                  sx={{
                    p: 3,
                    height: "100%",
                    borderRadius: 5,
                    border: "1px solid #E2E8F0",
                    transition: ".35s",
                    cursor: "pointer",

                    "&:hover": {
                      transform: "translateY(-8px)",
                      boxShadow: "0 18px 40px rgba(25,118,210,.15)",
                    },
                  }}
                >
                  <Stack
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                  >
                    <Box>
                      <Typography
                        sx={{
                          color: "#64748B",
                          fontSize: ".9rem",
                        }}
                      >
                        {card.title}
                      </Typography>

                      <Typography
                        sx={{
                          mt: 1,
                          fontWeight: 800,
                          fontSize: "2rem",
                          color: "#0F172A",
                        }}
                      >
                        {card.value}
                      </Typography>
                    </Box>

                    <Avatar
                      sx={{
                        bgcolor: card.color,
                        width: 56,
                        height: 56,
                      }}
                    >
                      {card.icon}
                    </Avatar>
                  </Stack>
                </Paper>
              </motion.div>
            </Grid>
          ))}
        </Grid>

        {/* ================= MAIN DASHBOARD ================= */}

        <Grid
          container
          spacing={3}
        >

          {/* LEFT SIDE */}

          <Grid
            item
            xs={12}
            lg={8}
          >
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
            >
              <Paper
                elevation={0}
                sx={{
                  p: 4,
                  borderRadius: 5,
                  border: "1px solid #E2E8F0",
                }}
              >
                <Stack
                  direction="row"
                  justifyContent="space-between"
                  alignItems="center"
                  mb={3}
                >
                  <Typography
                    sx={{
                      fontWeight: 700,
                      fontSize: "1.25rem",
                    }}
                  >
                    Monthly Water Usage
                  </Typography>

                  <Chip
                    label="July 2026"
                    color="primary"
                  />
                </Stack>

                <Box
                  sx={{
                    display: "flex",
                    alignItems: "flex-end",
                    justifyContent: "space-between",
                    height: 260,
                  }}
                >
                  {[90, 150, 120, 210, 180, 240, 190].map(
                    (height, index) => (
                      <Box
                        key={index}
                        sx={{
                          width: "11%",
                          height,
                          borderRadius: "16px 16px 0 0",
                          background:
                            "linear-gradient(180deg,#64B5F6,#1976D2)",

                          "&:hover": {
                            opacity: .8,
                          },
                        }}
                      />
                    )
                  )}
                </Box>

                <Stack
                  direction="row"
                  justifyContent="space-between"
                  mt={2}
                >
                  {[
                    "Mon",
                    "Tue",
                    "Wed",
                    "Thu",
                    "Fri",
                    "Sat",
                    "Sun",
                  ].map((day) => (
                    <Typography
                      key={day}
                      color="text.secondary"
                    >
                      {day}
                    </Typography>
                  ))}
                </Stack>
              </Paper>
            </motion.div>
          </Grid>

          {/* Continue in Part 2C */}
                    {/* ================= RIGHT SIDE ================= */}

          <Grid
            item
            xs={12}
            lg={4}
          >
            <Grid container spacing={3}>

              {/* Monthly Summary */}

              <Grid item xs={12}>
                <motion.div
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true }}
                  custom={0.2}
                >
                  <Paper
                    elevation={0}
                    sx={{
                      p: 3,
                      borderRadius: 5,
                      border: "1px solid #E2E8F0",
                      height: "100%",
                    }}
                  >
                    <Stack
                      direction="row"
                      spacing={1}
                      alignItems="center"
                      mb={3}
                    >
                      <AnalyticsRoundedIcon color="primary" />
                      <Typography fontWeight={700}>
                        Monthly Summary
                      </Typography>
                    </Stack>

                    <Stack spacing={2}>
                      <Box>
                        <Typography
                          variant="body2"
                          color="text.secondary"
                        >
                          Water Consumption
                        </Typography>

                        <LinearProgress
                          variant="determinate"
                          value={82}
                          sx={{
                            mt: 1,
                            height: 10,
                            borderRadius: 5,
                          }}
                        />

                        <Typography
                          sx={{
                            mt: 1,
                            fontWeight: 600,
                          }}
                        >
                          82%
                        </Typography>
                      </Box>

                      <Box>
                        <Typography
                          variant="body2"
                          color="text.secondary"
                        >
                          Bill Collection
                        </Typography>

                        <LinearProgress
                          color="success"
                          variant="determinate"
                          value={94}
                          sx={{
                            mt: 1,
                            height: 10,
                            borderRadius: 5,
                          }}
                        />

                        <Typography
                          sx={{
                            mt: 1,
                            fontWeight: 600,
                          }}
                        >
                          94%
                        </Typography>
                      </Box>
                    </Stack>
                  </Paper>
                </motion.div>
              </Grid>

              {/* Water Distribution + Leak Detection */}

              <Grid item xs={12}>
                <Grid container spacing={3}>

                  <Grid item xs={6}>
                    <Paper
                      elevation={0}
                      sx={{
                        p: 3,
                        borderRadius: 5,
                        border: "1px solid #E2E8F0",
                        height: "100%",
                        transition: ".3s",

                        "&:hover": {
                          transform: "translateY(-6px)",
                          boxShadow:
                            "0 15px 35px rgba(25,118,210,.12)",
                        },
                      }}
                    >
                      <PieChartRoundedIcon
                        color="primary"
                        sx={{
                          fontSize: 38,
                          mb: 2,
                        }}
                      />

                      <Typography
                        fontWeight={700}
                        gutterBottom
                      >
                        Distribution
                      </Typography>

                      <Typography
                        color="text.secondary"
                        fontSize=".9rem"
                      >
                        Domestic
                      </Typography>

                      <Typography fontWeight={700}>
                        65%
                      </Typography>

                      <Typography
                        color="text.secondary"
                        mt={2}
                        fontSize=".9rem"
                      >
                        Common Areas
                      </Typography>

                      <Typography fontWeight={700}>
                        35%
                      </Typography>
                    </Paper>
                  </Grid>

                  <Grid item xs={6}>
                    <Paper
                      elevation={0}
                      sx={{
                        p: 3,
                        borderRadius: 5,
                        border: "1px solid #E2E8F0",
                        height: "100%",
                        transition: ".3s",

                        "&:hover": {
                          transform: "translateY(-6px)",
                          boxShadow:
                            "0 15px 35px rgba(25,118,210,.12)",
                        },
                      }}
                    >
                      <WarningAmberRoundedIcon
                        sx={{
                          color: "#ED6C02",
                          fontSize: 38,
                          mb: 2,
                        }}
                      />

                      <Typography
                        fontWeight={700}
                        gutterBottom
                      >
                        Leak Detection
                      </Typography>

                      <Typography
                        color="text.secondary"
                        fontSize=".9rem"
                      >
                        Active Alerts
                      </Typography>

                      <Typography
                        fontWeight={700}
                        color="error.main"
                      >
                        2
                      </Typography>

                      <Typography
                        color="text.secondary"
                        mt={2}
                        fontSize=".9rem"
                      >
                        System Health
                      </Typography>

                      <Typography
                        fontWeight={700}
                        color="success.main"
                      >
                        Excellent
                      </Typography>
                    </Paper>
                  </Grid>

                </Grid>
              </Grid>

            </Grid>
          </Grid>

        </Grid>

      </Container>
    </Box>
  );
}