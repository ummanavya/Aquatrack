import React from "react";
import { motion } from "framer-motion";

import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
} from "@mui/material";

import WaterDropRoundedIcon from "@mui/icons-material/WaterDropRounded";
import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";
import AnalyticsRoundedIcon from "@mui/icons-material/AnalyticsRounded";
import NotificationsActiveRoundedIcon from "@mui/icons-material/NotificationsActiveRounded";
import SecurityRoundedIcon from "@mui/icons-material/SecurityRounded";
import DashboardRoundedIcon from "@mui/icons-material/DashboardRounded";

const features = [
  {
    icon: <WaterDropRoundedIcon sx={{ fontSize: 42 }} />,
    title: "Live Water Monitoring",
    description:
      "Track real-time water consumption across every apartment with instant usage updates.",
  },
  {
    icon: <ReceiptLongRoundedIcon sx={{ fontSize: 42 }} />,
    title: "Automated Billing",
    description:
      "Generate accurate monthly bills automatically using configurable tariff plans.",
  },
  {
    icon: <AnalyticsRoundedIcon sx={{ fontSize: 42 }} />,
    title: "Consumption Analytics",
    description:
      "Visual dashboards provide insights into water usage trends and conservation.",
  },
  {
    icon: <NotificationsActiveRoundedIcon sx={{ fontSize: 42 }} />,
    title: "Leak Detection",
    description:
      "Receive instant alerts whenever abnormal water consumption is detected.",
  },
  {
    icon: <DashboardRoundedIcon sx={{ fontSize: 42 }} />,
    title: "Smart Dashboard",
    description:
      "Manage apartments, households, billing and reports from one centralized dashboard.",
  },
  {
    icon: <SecurityRoundedIcon sx={{ fontSize: 42 }} />,
    title: "Secure Platform",
    description:
      "Role-based authentication with secure access for administrators and residents.",
  },
];

const fadeUp = {
  hidden: {
    opacity: 0,
    y: 40,
  },
  show: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      delay,
    },
  }),
};

export default function FeaturesSection() {
  return (
    <Box
      sx={{
        py: {
          xs: 10,
          md: 14,
        },
        bgcolor: "#ffffff",
      }}
    >
      <Container maxWidth="xl">

        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >
          <Typography
            align="center"
            sx={{
              color: "#1976D2",
              fontWeight: 700,
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            Features
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              fontWeight: 800,
              color: "#0F172A",
              fontSize: {
                xs: "2rem",
                md: "3rem",
              },
            }}
          >
            Everything You Need
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              maxWidth: 760,
              mx: "auto",
              color: "#64748B",
              lineHeight: 1.8,
            }}
          >
            AquaTrack provides a complete water management solution
            designed for apartments, residential communities and
            property administrators.
          </Typography>
        </motion.div>

        {/* Continue in Part 3B */}
                <Grid
          container
          spacing={4}
          sx={{
            mt: 6,
          }}
        >
          {features.map((feature, index) => (
            <Grid
              item
              xs={12}
              sm={6}
              lg={4}
              key={feature.title}
            >
              <motion.div
                variants={fadeUp}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true }}
                custom={index * 0.15}
              >
                <Paper
                  elevation={0}
                  sx={{
                    height: "100%",
                    p: 4,
                    borderRadius: "24px",
                    border: "1px solid #E2E8F0",
                    transition: "all .35s ease",
                    bgcolor: "#fff",

                    "&:hover": {
                      transform: "translateY(-10px)",
                      borderColor: "#42A5F5",
                      boxShadow:
                        "0 20px 50px rgba(25,118,210,.15)",
                    },
                  }}
                >
                  <Box
                    sx={{
                      width: 74,
                      height: 74,
                      borderRadius: "18px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",

                      background:
                        "linear-gradient(135deg,#1976D2,#42A5F5)",

                      color: "#fff",
                      mb: 3,
                    }}
                  >
                    {feature.icon}
                  </Box>

                  <Typography
                    sx={{
                      fontWeight: 700,
                      fontSize: "1.35rem",
                      color: "#0F172A",
                      mb: 2,
                    }}
                  >
                    {feature.title}
                  </Typography>

                  <Typography
                    sx={{
                      color: "#64748B",
                      lineHeight: 1.8,
                    }}
                  >
                    {feature.description}
                  </Typography>
                </Paper>
              </motion.div>
            </Grid>
          ))}
        </Grid>

        {/* Continue in Part 3C */}
                <Box
          sx={{
            mt: 10,
            borderRadius: "30px",
            overflow: "hidden",
            p: {
              xs: 4,
              md: 7,
            },
            background:
              "linear-gradient(135deg,#0F172A 0%,#1976D2 50%,#42A5F5 100%)",
          }}
        >
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            custom={0.3}
          >
            <Typography
              align="center"
              sx={{
                color: "#FFFFFF",
                fontWeight: 800,
                fontSize: {
                  xs: "2rem",
                  md: "3rem",
                },
              }}
            >
              One Platform. Complete Water Management.
            </Typography>

            <Typography
              align="center"
              sx={{
                mt: 3,
                maxWidth: 850,
                mx: "auto",
                color: "rgba(255,255,255,.9)",
                lineHeight: 1.9,
                fontSize: 18,
              }}
            >
              AquaTrack brings together water monitoring, automated
              billing, smart analytics, leak detection, household
              management and secure administration into a single,
              easy-to-use platform built for modern apartment
              communities.
            </Typography>

            <Grid
              container
              spacing={4}
              sx={{
                mt: 5,
              }}
            >
              {[
                {
                  number: "24/7",
                  text: "Live Monitoring",
                },
                {
                  number: "100%",
                  text: "Automated Billing",
                },
                {
                  number: "AI",
                  text: "Leak Detection",
                },
                {
                  number: "Secure",
                  text: "Role Based Access",
                },
              ].map((item) => (
                <Grid
                  item
                  xs={6}
                  md={3}
                  key={item.text}
                >
                  <Box
                    sx={{
                      textAlign: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#42A5F5",
                        fontWeight: 800,
                        fontSize: {
                          xs: "2rem",
                          md: "2.6rem",
                        },
                      }}
                    >
                      {item.number}
                    </Typography>

                    <Typography
                      sx={{
                        color: "rgba(255,255,255,.85)",
                        mt: 1,
                      }}
                    >
                      {item.text}
                    </Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </motion.div>
        </Box>

      </Container>
    </Box>
  );
}