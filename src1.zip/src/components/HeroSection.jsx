import React from "react";
import { Box, Typography } from "@mui/material";

export default function HeroSection() {
  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#1976d2",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Typography variant="h2" color="white">
        Hero Works
      </Typography>
    </Box>
  );
}