import React from "react";
import { motion } from "framer-motion";

import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
  Stack,
} from "@mui/material";

import ApartmentRoundedIcon from "@mui/icons-material/ApartmentRounded";
import WaterDropRoundedIcon from "@mui/icons-material/WaterDropRounded";
import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";
import VerifiedRoundedIcon from "@mui/icons-material/VerifiedRounded";

const stats = [
  {
    icon: <ApartmentRoundedIcon sx={{ fontSize: 42 }} />,
    value: "120+",
    title: "Apartment Communities",
    description:
      "Residential communities actively managing water usage with AquaTrack.",
  },
  {
    icon: <WaterDropRoundedIcon sx={{ fontSize: 42 }} />,
    value: "2.8M L",
    title: "Water Monitored",
    description:
      "Real-time water consumption tracked every month across all apartments.",
  },
  {
    icon: <ReceiptLongRoundedIcon sx={{ fontSize: 42 }} />,
    value: "18K+",
    title: "Bills Generated",
    description:
      "Automated billing with accurate tariff calculation and invoice generation.",
  },
  {
    icon: <VerifiedRoundedIcon sx={{ fontSize: 42 }} />,
    value: "99.9%",
    title: "Billing Accuracy",
    description:
      "Reliable calculations with leak detection and smart consumption analysis.",
  },
];

const fadeUp = {
  hidden: {
    opacity: 0,
    y: 40,
  },
  show: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      delay,
    },
  }),
};

export default function StatisticsSection() {
  return (
    <Box
      sx={{
        py: {
          xs: 10,
          md: 14,
        },
        bgcolor: "#F8FAFC",
      }}
    >
      <Container maxWidth="xl">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          custom={0}
        >
          <Typography
            align="center"
            sx={{
              color: "#1976D2",
              fontWeight: 700,
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            Trusted Platform
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              fontWeight: 800,
              color: "#0F172A",
              fontSize: {
                xs: "2rem",
                md: "3rem",
              },
            }}
          >
            AquaTrack at a Glance
          </Typography>

          <Typography
            align="center"
            sx={{
              mt: 2,
              maxWidth: 760,
              mx: "auto",
              color: "#64748B",
              lineHeight: 1.8,
            }}
          >
            Monitor water consumption, automate billing, identify leaks,
            and optimize apartment water management using one intelligent platform.
          </Typography>
        </motion.div>

        {/* Continue in Part 2B */}
                <Grid
          container
          spacing={4}
          sx={{
            mt: 6,
          }}
        >
          {stats.map((item, index) => (
            <Grid
              item
              xs={12}
              sm={6}
              lg={3}
              key={item.title}
            >
              <motion.div
                variants={fadeUp}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true }}
                custom={index * 0.15}
              >
                <Paper
                  elevation={0}
                  sx={{
                    height: "100%",
                    p: 4,
                    borderRadius: "24px",
                    bgcolor: "#FFFFFF",
                    border: "1px solid #E2E8F0",
                    transition: "all .35s ease",

                    "&:hover": {
                      transform: "translateY(-10px)",
                      borderColor: "#42A5F5",
                      boxShadow:
                        "0 20px 50px rgba(25,118,210,.15)",
                    },
                  }}
                >
                  <Stack
                    spacing={3}
                    alignItems="flex-start"
                  >
                    <Box
                      sx={{
                        width: 72,
                        height: 72,
                        borderRadius: "18px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",

                        color: "#fff",

                        background:
                          "linear-gradient(135deg,#1976D2,#42A5F5)",
                      }}
                    >
                      {item.icon}
                    </Box>

                    <Typography
                      sx={{
                        fontSize: "2.3rem",
                        fontWeight: 800,
                        color: "#1976D2",
                      }}
                    >
                      {item.value}
                    </Typography>

                    <Typography
                      sx={{
                        fontWeight: 700,
                        fontSize: "1.2rem",
                        color: "#0F172A",
                      }}
                    >
                      {item.title}
                    </Typography>

                    <Typography
                      sx={{
                        color: "#64748B",
                        lineHeight: 1.8,
                      }}
                    >
                      {item.description}
                    </Typography>
                  </Stack>
                </Paper>
              </motion.div>
            </Grid>
          ))}
        </Grid>

        {/* Continue in Part 2C */}
                <Box
          sx={{
            mt: 10,
            p: {
              xs: 4,
              md: 6,
            },
            borderRadius: "30px",
            overflow: "hidden",
            position: "relative",
            background:
              "linear-gradient(135deg,#1976D2 0%,#42A5F5 100%)",
          }}
        >
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            custom={0.3}
          >
            <Stack
              spacing={3}
              alignItems="center"
              textAlign="center"
            >
              <Typography
                sx={{
                  color: "#fff",
                  fontWeight: 800,
                  fontSize: {
                    xs: "2rem",
                    md: "3rem",
                  },
                }}
              >
                Smart Water Management Starts Here
              </Typography>

              <Typography
                sx={{
                  maxWidth: 800,
                  color: "rgba(255,255,255,.9)",
                  lineHeight: 1.8,
                  fontSize: 18,
                }}
              >
                AquaTrack combines intelligent water monitoring,
                automated billing, leak detection, consumption
                analytics and apartment management into one
                powerful platform for modern residential communities.
              </Typography>

              <Stack
                direction={{
                  xs: "column",
                  sm: "row",
                }}
                spacing={5}
                sx={{
                  mt: 2,
                }}
              >
                <Box>
                  <Typography
                    sx={{
                      color: "#fff",
                      fontWeight: 800,
                      fontSize: 34,
                    }}
                  >
                    24/7
                  </Typography>

                  <Typography
                    sx={{
                      color: "rgba(255,255,255,.85)",
                    }}
                  >
                    Live Monitoring
                  </Typography>
                </Box>

                <Box>
                  <Typography
                    sx={{
                      color: "#fff",
                      fontWeight: 800,
                      fontSize: 34,
                    }}
                  >
                    AI
                  </Typography>

                  <Typography
                    sx={{
                      color: "rgba(255,255,255,.85)",
                    }}
                  >
                    Leak Detection
                  </Typography>
                </Box>

                <Box>
                  <Typography
                    sx={{
                      color: "#fff",
                      fontWeight: 800,
                      fontSize: 34,
                    }}
                  >
                    100%
                  </Typography>

                  <Typography
                    sx={{
                      color: "rgba(255,255,255,.85)",
                    }}
                  >
                    Digital Billing
                  </Typography>
                </Box>
              </Stack>
            </Stack>
          </motion.div>
        </Box>

      </Container>
    </Box>
  );
}